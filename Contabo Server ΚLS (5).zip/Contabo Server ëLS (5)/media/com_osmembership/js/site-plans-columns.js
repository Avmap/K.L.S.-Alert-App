(function (document, $) {
    $(document).ready(function() {
        $(".osm-item-description-text").equalHeights(Joomla.getOptions('minHeight'));
    });
})(document, OSM.jQuery);