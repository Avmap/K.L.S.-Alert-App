(function (document, $) {
    $(document).ready(function () {
        buildStateFields('state', 'country', Joomla.getOptions('selectedState'));
    });
})(document, jQuery);