(function ($) {
    $(document).ready(function () {
        $('a.modal').colorbox();
    });
})(jQuery);