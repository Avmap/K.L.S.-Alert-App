(function (document, $) {
    $(document).ready(function() {
        $(".osm-user-profile-wrapper").equalHeights(Joomla.getOptions('minHeight'));
    });
})(document, OSM.jQuery);