(function (document, $) {
    $(document).ready(function() {
        $(".osm-item-description-text").equalHeights(130);
    });
})(document, OSM.jQuery);