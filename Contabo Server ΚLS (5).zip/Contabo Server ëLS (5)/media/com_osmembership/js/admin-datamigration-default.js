(function ($) {
    $(document).ready(function () {
        setTimeout(function () {
            document.adminForm.submit();
        }, 5000);
    });
})(jQuery);