(function (document, $) {
    Joomla.submitbutton = function (pressbutton) {
        var form = document.adminForm;

        if (pressbutton === 'cancel') {
            Joomla.submitform(pressbutton, form);
        } else {
            //Validate the entered data before submitting
            if (form.title.value === '') {
                alert(Joomla.JText._('OSM_ENTER_PLAN_TITLE'));
                form.title.focus();
                return;
            }

            var lifetimeMembership = $('input[name="lifetime_membership"]:checked').val();

            if (!form.subscription_length.value && lifetimeMembership == 0) {
                alert(Joomla.JText._('OSM_ENTER_SUBSCRIPTION_LENGTH'));
                form.subscription_length.focus();
                return;
            }
            var recurringSubscription = $('input[name="recurring_subscription"]:checked').val();

            if (recurringSubscription == 1 && form.price.value <= 0) {
                alert(Joomla.JText._('OSM_PRICE_REQUIRED'));
                form.price.focus();
                return;
            }

            if ($('.article_checkbox').length) {
                $('.article_checkbox').attr("checked", false);
            }

            if ($('.k2_item_checkbox').length) {
                $('.k2_item_checkbox').attr("checked", false);
            }

            Joomla.submitform(pressbutton, form);
        }
    };

    $(document).ready(function () {
        $('.osm-waring').hide();

        if ($('#recurring').val() == 1 && $('#price').val() <= 0) {
            $('.osm-waring').slideDown();
        }
    });
})(document, jQuery);