<?php
use Jose\Component\Core\AlgorithmManager;
use Jose\Component\Core\Converter\StandardConverter;
use Jose\Component\Core\JWK;
use Jose\Component\Signature\Algorithm\HS256;
use Jose\Component\Signature\JWSBuilder;
use Jose\Component\Signature\Serializer\JWSSerializerManager;
use Jose\Component\Signature\Serializer\CompactSerializer;
use Jose\Component\Signature\JWSVerifier;
use Jose\Component\Signature\JWSLoader;

use Jose\Component\Checker\HeaderCheckerManager;
use Jose\Component\Checker\AlgorithmChecker;
use Jose\Component\Signature\JWSTokenSupport;

use Jose\Component\Checker\ClaimCheckerManager;
use Jose\Component\Checker;
class JwtAuthenticationProvider extends Thruway\Authentication\AbstractAuthProviderClient {

    public function __construct(Array $authRealms,$key) {
        parent::__construct($authRealms);
    }

    public function getMethodName() {
        return 'jwt';
    }

    public function processAuthenticate($signature, $extra = null)
    {
		$err="";
		
		try{
			$claims = Alert_Common::validateToken($signature,$err);
		}catch(Exception $ex){
			print_r($ex);
		}			
		if (empty($err)){
			return ["SUCCESS", ["authid" => $claims['userID']]];
		}else{
			echo $err;
			return ["FAILURE"];
		}
    }
}
