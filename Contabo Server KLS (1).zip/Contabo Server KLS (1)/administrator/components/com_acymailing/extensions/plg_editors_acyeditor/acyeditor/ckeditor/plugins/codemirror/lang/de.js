CKEDITOR.plugins.setLang( 'codemirror', 'de', {
    toolbar: 'Quellcode',
    searchCode: 'Quellcode durchsuchen',
	autoFormat: 'Auswahl formatieren',
	commentSelectedRange: 'Auswahl auskommentieren',
	uncommentSelectedRange: 'Auskommentierung entfernen',
	autoCompleteToggle: 'HTML Tag Autovervollständigen de-/aktivieren'
});

