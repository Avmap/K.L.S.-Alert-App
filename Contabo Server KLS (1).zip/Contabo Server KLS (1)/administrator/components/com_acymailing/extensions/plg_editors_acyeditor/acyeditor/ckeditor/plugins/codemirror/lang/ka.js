CKEDITOR.plugins.setLang( 'codemirror', 'ka', {
	toolbar: 'კოდები',
	searchCode: 'Search Source',
	autoFormat: 'Format Selection',
	commentSelectedRange: 'Comment Selection',
	uncommentSelectedRange: 'Uncomment Selection',
	autoCompleteToggle: 'Enable/Disable HTML Tag Autocomplete'
});

