<?php /* /var/www/vhosts/alert247.gr/httpdocs/administrator/components/com_admintools/tmpl/HtaccessMaker/default.blade.php */ ?>
<?php
/**
 * @package   admintools
 * @copyright Copyright (c)2010-2021 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') || die;

/** @var $this Akeeba\AdminTools\Admin\View\HtaccessMaker\Html */

$config = $this->htconfig;

?>
<div class="akeeba-block--info">
	<p>
		<strong>
			<?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WILLTHISWORK'); ?>
		</strong>
	</p>
	<p>
		<?php if($this->isSupported == 0): ?>
			<?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WILLTHISWORK_NO'); ?>
		<?php elseif($this->isSupported == 1): ?>
			<?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WILLTHISWORK_YES'); ?>
		<?php else: ?>
			<?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WILLTHISWORK_MAYBE'); ?>
		<?php endif; ?>
	</p>
</div>

<div class="akeeba-block--warning">
	<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WARNING'); ?></h3>

	<p><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WARNTEXT'); ?></p>

	<p><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_TUNETEXT'); ?></p>
</div>

<form name="adminForm" id="adminForm" action="index.php" method="post" class="akeeba-form--horizontal">
	<?php /* ======================================================================= */ ?>
	<div class="akeeba-panel--primary">
		<header class="akeeba-block-header">
			<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_BASICSEC'); ?></h3>
		</header>

		<div class="akeeba-form-group">
			<label for="nodirlists"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_NODIRLISTS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'nodirlists', $config->nodirlists); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="fileinj"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FILEINJ'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'fileinj', $config->fileinj); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="phpeaster"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_PHPEASTER'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'phpeaster', $config->phpeaster); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="leftovers"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_LEFTOVERS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'leftovers', $config->leftovers); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="clickjacking"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_CLICKJACKING'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'clickjacking', $config->clickjacking); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="reducemimetyperisks"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_REDUCEMIMETYPERISKS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'reducemimetyperisks', $config->reducemimetyperisks); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="reflectedxss"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_REFLECTEDXSS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'reflectedxss', $config->reflectedxss); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="svgneutralise"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SVGNEUTRALISE'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'svgneutralise', $config->svgneutralise); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="noserversignature"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_NOSERVERSIGNATURE'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'noserversignature', $config->noserversignature); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="notransform"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_NOTRANSFORM'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'notransform', $config->notransform); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="nohoggers"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_NOHOGGERS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'nohoggers', $config->nohoggers); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="hoggeragents"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_HOGGERAGENTS'); ?></label>

			<textarea rows="10" name="hoggeragents"
					  id="hoggeragents"><?php echo implode("\n", $config->hoggeragents); ?></textarea>
		</div>
	</div>

	<?php /* ======================================================================= */ ?>
	<div class="akeeba-panel--primary">
		<header class="akeeba-block-header">
			<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SERVERPROT'); ?></h3>
		</header>

		<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SERVERPROT_TOGGLES'); ?></h3>

		<div class="akeeba-form-group">
			<label for="backendprot"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_BACKENDPROT'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'backendprot', $config->backendprot); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="frontendprot"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FRONTENDPROT'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'frontendprot', $config->frontendprot); ?>
		</div>

		<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SERVERPROT_FINETUNE'); ?></h3>

		<div class="akeeba-form-group">
			<label for="bepexdirs"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_BEPEXDIRS'); ?></label>

			<textarea cols="80" rows="10" name="bepexdirs"
					  id="bepexdirs"><?php echo $this->escape(implode("\n", $config->bepexdirs)); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="bepextypes"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_BEPEXTYPES'); ?></label>

			<textarea cols="80" rows="10" name="bepextypes"
					  id="bepextypes"><?php echo $this->escape(implode("\n", $config->bepextypes)); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="bestaticrisks"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_BESTATICRISKS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'bestaticrisks', $config->bestaticrisks); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="fepexdirs"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FEPEXDIRS'); ?></label>

			<textarea cols="80" rows="10" name="fepexdirs"
					  id="fepexdirs"><?php echo $this->escape(implode("\n", $config->fepexdirs)); ?></textarea>
		</div>
		<div class="akeeba-form-group">
			<label for="fepextypes"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FEPEXTYPES'); ?></label>

			<textarea cols="80" rows="10" name="fepextypes"
					  id="fepextypes"><?php echo $this->escape(implode("\n", $config->fepextypes)); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="festaticrisks"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FESTATICRISKS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'festaticrisks', $config->festaticrisks); ?>
		</div>

		<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SERVERPROT_EXCEPTIONS'); ?></h3>

		<div class="akeeba-form-group">
			<label for="exceptionfiles"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_EXCEPTIONFILES'); ?></label>

			<textarea cols="80" rows="10" name="exceptionfiles"
					  id="exceptionfiles"><?php echo $this->escape(implode("\n", $config->exceptionfiles)); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="exceptiondirs"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_EXCEPTIONDIRS'); ?></label>

			<textarea cols="80" rows="10" name="exceptiondirs"
					  id="exceptiondirs"><?php echo $this->escape(implode("\n", $config->exceptiondirs)); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="fullaccessdirs"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FULLACCESSDIRS'); ?></label>

			<textarea cols="80" rows="10" name="fullaccessdirs"
					  id="fullaccessdirs"><?php echo $this->escape(implode("\n", $config->fullaccessdirs)); ?></textarea>
		</div>
	</div>

	<?php /* ======================================================================= */ ?>
	<div class="akeeba-panel--primary">
		<header class="akeeba-block-header">
			<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_CUSTOM'); ?></h3>
		</header>

		<div class="akeeba-form-group">
			<label for="custhead"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_CUSTHEAD'); ?></label>

			<textarea cols="80" rows="10" name="custhead"
					  id="custhead"><?php echo $this->escape($config->custhead); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="custfoot"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_CUSTFOOT'); ?></label>

			<textarea cols="80" rows="10" name="custfoot"
					  id="custfoot"><?php echo $this->escape($config->custfoot); ?></textarea>
		</div>
	</div>
	<!-- ======================================================================= -->
	<div class="akeeba-panel--primary">
		<header class="akeeba-block-header">
			<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_OPTUTIL'); ?></h3>
		</header>

		<div class="akeeba-form-group">
			<label for="fileorder"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FILEORDER'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'fileorder', $config->fileorder); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="exptime"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_EXPTIME'); ?></label>

			<?php echo \Akeeba\AdminTools\Admin\Helper\Select::exptime('exptime', null, $config->exptime); ?>

		</div>

		<div class="akeeba-form-group">
			<label for="autocompress"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_AUTOCOMPRESS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'autocompress', $config->autocompress); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="forcegzip"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_FORCEGZIP'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'forcegzip', $config->forcegzip); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="autoroot"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_AUTOROOT'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'autoroot', $config->autoroot); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="wwwredir"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_WWWREDIR'); ?></label>

			<?php echo \Akeeba\AdminTools\Admin\Helper\Select::wwwredirs(
				'wwwredir',
				$this->enableRedirects ? [] : ['disabled' => 'disabled'],
				$this->enableRedirects ? $config->wwwredir : 0
				); ?>

		</div>

		<div class="akeeba-form-group">
			<label for="olddomain"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_OLDDOMAIN'); ?></label>

			<input type="text" name="olddomain" id="olddomain" value="<?php echo $this->escape($config->olddomain); ?>">
		</div>

		<div class="akeeba-form-group">
			<label for="httpsurls"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_HTTPSURLS'); ?></label>

			<textarea cols="80" rows="10" name="httpsurls"
					  id="httpsurls"><?php echo $this->escape(implode("\n", $config->httpsurls)); ?></textarea>
		</div>

		<div class="akeeba-form-group">
			<label for="hstsheader"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_HSTSHEADER'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'hstsheader', $config->hstsheader); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="notracetrack"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_NOTRACETRACK'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'notracetrack', $config->notracetrack); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="cors"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_CORS'); ?></label>

			<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.genericlist', \Akeeba\AdminTools\Admin\Helper\Select::getCorsOptions(), 'cors', ['list.select' => $config->cors]); ?>
		</div>

		<div class="akeeba-form-group">
			<label for="utf8charset"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_UTF8CHARSET'); ?></label>

			<div>
				<?php echo \Joomla\CMS\HTML\HTMLHelper::_('FEFHelp.select.booleanswitch', 'utf8charset', $config->utf8charset); ?>
			</div>
		</div>

		<div class="akeeba-form-group">
			<label for="etagtype"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_ETAGTYPE'); ?></label>

			<?php echo \Akeeba\AdminTools\Admin\Helper\Select::etagtype('etagtype', ['class' => 'input-medium'], $config->etagtype); ?>

		</div>

		<div class="akeeba-form-group">
			<label for="referrerpolicy"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_REFERERPOLICY'); ?></label>

			<?php echo \Akeeba\AdminTools\Admin\Helper\Select::referrerpolicy('referrerpolicy', [], $config->referrerpolicy); ?>

		</div>
	</div>

	<div class="akeeba-panel--primary">
		<header class="akeeba-block-header">
			<h3><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SYSCONF'); ?></h3>
		</header>

		<div class="akeeba-form-group">
			<label for="httpshost"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_HTTPSHOST'); ?></label>

			<input type="text" name="httpshost" id="httpshost" value="<?php echo $this->escape($config->httpshost); ?>">
		</div>

		<div class="akeeba-form-group">
			<label for="httphost"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_HTTPHOST'); ?></label>

			<input type="text" name="httphost" id="httphost" value="<?php echo $this->escape($config->httphost); ?>">
		</div>

		<div class="akeeba-form-group">
			<label for="symlinks"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_SYMLINKS'); ?></label>

			<?php echo \Akeeba\AdminTools\Admin\Helper\Select::symlinks('symlinks', ['class' => 'input-medium'], $config->symlinks); ?>

		</div>

		<div class="akeeba-form-group">
			<label for="rewritebase"><?php echo \Joomla\CMS\Language\Text::_('COM_ADMINTOOLS_LBL_HTACCESSMAKER_REWRITEBASE'); ?></label>

			<input type="text" name="rewritebase" id="rewritebase"
				   value="<?php echo $this->escape($config->rewritebase); ?>">
		</div>
	</div>

	<input type="hidden" name="option" value="com_admintools" />
	<input type="hidden" name="view" value="HtaccessMaker" />
	<input type="hidden" name="task" value="save" />
	<input type="hidden" name="<?php echo $this->container->platform->getToken(true); ?>" value="1" />
</form>
