<?php
/**
 * @package     Falang for Joomla!
 * @author      Stéphane Bouey <stephane.bouey@faboba.com> - http://www.faboba.com
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright   Copyright (C) 2010-2017. Faboba.com All rights reserved.
 */

// No direct access to this file
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('/libraries/avmap/flags/css/flag-icon.min.css');
$svgCode = "";

?>



<ul class="<?php echo $params->get('inline', 1) ? 'lang-inline' : 'lang-block';?>">
    <?php foreach($list as $language):?>
	<?php
	switch ($language->image){
		case 'el_gr':
			$svgCode = "gr";
			break;
		case 'zh_cn':
			$svgCode = "cn";
			break;
		case 'en_gb':
			$svgCode = "gb";
			break;
		default:
			$svgCode = substr($language->image,0,strpos($language->image,'_'));
	}
	?>
        <?php if ($params->get('show_active', 0) || !$language->active):?>
            <li class="<?php echo $language->active ? 'lang-active' : '';?>" dir="<?php echo JLanguage::getInstance($language->lang_code)->isRTL() ? 'rtl' : 'ltr' ?>">
                <?php if ($language->display) { ?>
                    <a href="<?php echo $language->link;?>">
                        <?php if ($params->get('image', 1)):?>
							<span class="flag-icon flag-icon-<?=$svgCode?>"></span>
                        <?php endif; ?>
                        <?php if ($params->get('show_name', 1)):?>
                            <?php echo $params->get('full_name', 1) ? $language->title_native : strtoupper($language->sef);?>
                        <?php endif; ?>
                    </a>
                <?php } else { ?>
                    <?php if ($params->get('image', 1)):?>
						<span class="flag-icon flag-icon-<?=$svgCode?>"></span>
                    <?php endif; ?>
                    <?php if ($params->get('show_name', 1)):?>
                        <?php echo $params->get('full_name', 1) ? $language->title_native : strtoupper($language->sef);?>
                    <?php endif; ?>
                <?php } ?>
            </li>
        <?php endif;?>
    <?php endforeach;?>
</ul>
