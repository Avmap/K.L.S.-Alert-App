/**
 * @package     Joomla.Site
 * @subpackage  Templates.beez3
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @since       3.2
 */

jQuery(function($) {
	'use strict';

	$(document).on('click', ".btn-group label:not(.active)", function() {
			var $label = $(this);
			var $input = $(document.getElementById($label.attr('for')));

			if ($input.prop('checked'))
			{
				return;
			}

			$label.closest('.btn-group').find("label").removeClass('active btn-success btn-danger btn-primary');

			var btnClass = 'primary';

			if ($input.val() != '')
			{
				var reversed = $label.closest('.btn-group').hasClass('btn-group-reversed');
				btnClass = ($input.val() == 0 ? !reversed : reversed) ? 'danger' : 'success';
			}

			$label.addClass('active btn-' + btnClass);
			$input.prop('checked', true).trigger('change');
		})
		.on('subform-row-add', initButtonGroup)
		.on('subform-row-add', initTooltip);

	initButtonGroup();
	initTooltip();

	// Called once on domready, again when a subform row is added
	function initTooltip(event, container)
	{
		$(container || document).find('*[rel=tooltip]').tooltip();
	}

	// Called once on domready, again when a subform row is added
	function initButtonGroup(event, container)
	{
		var $container = $(container || document);

		// Turn radios into btn-group
		$container.find('.radio.btn-group label').addClass('btn');

		// Setup coloring for buttons
		$container.find('.btn-group input:checked').each(function() {
			var $input  = $(this);
			var $label = $(document.querySelector('label[for=' + $input.attr('id') + ']'));
			var btnClass = 'primary';

			if ($input.val() != '')
			{
				var reversed = $input.parent().hasClass('btn-group-reversed');
				btnClass = ($input.val() == 0 ? !reversed : reversed) ? 'danger' : 'success';
			}

			$label.addClass('active btn-' + btnClass);
		});
	}
});
