<?php
	const _JEXEC = 1;



	if (!defined('_JDEFINES'))
	{
		define('JPATH_BASE', __DIR__);
		require_once JPATH_BASE . '/includes/defines.php';
	}

	// Get the framework.
	require_once JPATH_LIBRARIES . '/import.legacy.php';

	// Bootstrap the CMS libraries.
	require_once JPATH_LIBRARIES . '/cms.php';
	require_once JPATH_CONFIGURATION . '/configuration.php';

    require_once (__DIR__) . '/libraries/avmap/vendor/autoload.php';

	require_once __DIR__.'/plugins/jbackend/alert/alert_common.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_stats.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_otp.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_users.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_messages.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_subscriptions.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_mobile.php';
	require_once __DIR__.'/plugins/jbackend/alert/alert_testing.php';
	//require_once (__DIR__) . '/libraries/avmap/SimpleAuthProviderClient.php';
	require_once (__DIR__) . '/libraries/avmap/JwtAuthenticationProvider.php'; 
	error_reporting(error_reporting() & ~E_NOTICE);
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	function exception_error_handler($errno, $errstr, $errfile, $errline ) {
		throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
	}
	set_error_handler("exception_error_handler");
	
	function __fatalHandler()
	{
		$error = error_get_last();

		// Check if it's a core/fatal error, otherwise it's a normal shutdown
		

			echo "<pre>fatal error:\n";
			print_r($error);
			var_dump(debug_backtrace());
			debug_print_backtrace();
			echo "</pre>";
			die ('wtf');
		
	}

	register_shutdown_function('__fatalHandler');
	
	use Thruway\Peer\Router;
	use Thruway\Transport\RatchetTransportProvider;
	
	class AlertWAMP extends JApplicationCli
	{
	/**
	 * Entry point for the script
	 *
	 * @return  void
	 *
	 * @since   2.5
	 */
	public function doExecute()
	{
	
		$loop   = \React\EventLoop\Factory::create();
		$pusher = new \Thruway\Peer\Client("realm1", $loop);

		$pusher->on('open', function ($session) use ($loop) {
			$context = new React\ZMQ\Context($loop);
			$pull    = $context->getSocket(ZMQ::SOCKET_PULL);
			$pull->bind('tcp://127.0.0.1:5555');

			$pull->on('message', function ($entry) use ($session) {
				$entryData = json_decode($entry, true);
				if (isset($entryData['category'])) {
					$session->publish("gr.avmap.".$entryData['category'], [$entryData]);
				}
			});
		});

		$router = new Thruway\Peer\Router($loop);
		$router->addInternalClient($pusher);
		
		
		try{	
			$router->registerModule(new \Thruway\Authentication\AuthenticationManager());
			$router->addInternalClient(new JwtAuthenticationProvider(['realm1'],false)); 
			
			$router->addTransportProvider(new Thruway\Transport\RatchetTransportProvider("127.0.0.1", 8080));
			$router->start();
		}catch(Exception $ex){
			print_r($ex);
		}
	}
} 

JApplicationCli::getInstance('AlertWAMP')->execute();