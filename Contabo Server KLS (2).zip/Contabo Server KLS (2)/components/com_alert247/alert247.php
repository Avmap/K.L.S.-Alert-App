<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Alert247
 * @author     AVMap GIS S.A. <support@avmap.gr>
 * @copyright  2019 AVMap GIS S.A.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Include dependancies
jimport('joomla.application.component.controller');

JLoader::registerPrefix('Alert247', JPATH_COMPONENT);
JLoader::register('Alert247Controller', JPATH_COMPONENT . '/controller.php');


// Execute the task.
$controller = JControllerLegacy::getInstance('Alert247');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
