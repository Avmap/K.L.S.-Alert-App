<?php
/**
 * jBackend component for Joomla
 *
 * @author selfget.com (info@selfget.com)
 * @package jBackend
 * @copyright Copyright 2014 - 2018
 * @license GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @link http://www.selfget.com
 * @version 3.8.0
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once JPATH_COMPONENT.'/helpers/jbackend.php';

class jBackendViewRequest extends JViewLegacy
{
  protected $item;

  protected $params;

  protected $state;

  public function display($tpl = null)
  {
    // Initialise variables
    $app = JFactory::getApplication('site');

    $this->state = $this->get('State');
    $this->params = $this->state->get('parameters.menu');

    if (is_null($this->params))
    {
      $params = JComponentHelper::getParams('com_jbackend');
      $is_default = true;
      $endpoint = '0';
      $access_type = $params->get('default_access_type', 'key'); // free/user/key
      $enable_trace = $params->get('default_enable_trace', '0');
      $enable_cors = '0'; // disabled
      $force_ssl = $params->get('default_force_ssl', '0');
      $enabled_modules = '1'; // all
      $selected_modules = array();
    } else {
      $is_default = false;
      $endpoint = $app->getMenu()->getActive()->id;
      $access_type = $this->params->get('access_type', 'key'); // free/user/key
      $enable_trace = $this->params->get('enable_trace', '0');
      $enable_cors = $this->params->get('enable_cors', '0');
      $force_ssl = $this->params->get('force_ssl', '0');
      $enabled_modules = $this->params->get('enabled_modules', '1');
      $selected_modules = $this->params->get('selected_modules', array());
    }

    // Check if force to SSL
    if ($force_ssl != '0')
    {
      $uri = JUri::getInstance();
      if (strtolower($uri->getScheme()) != 'https')
      {
        // Forward to https
        $uri->setScheme('https');
        $app->redirect((string) $uri);
      }
    }

    jBackendHelper::globals_set('session', 'is_default', $is_default);
    jBackendHelper::globals_set('session', 'endpoint', $endpoint);
    jBackendHelper::globals_set('session', 'access_type', $access_type);
    jBackendHelper::globals_set('session', 'enabled_modules', $enabled_modules);
    jBackendHelper::globals_set('session', 'selected_modules', $selected_modules);

    if ($enable_trace)
    {
      // Collect pre-execution log information
      $log = array();
      $log['duration'] = microtime(true);
      $now = JFactory::getDate((int)$log['duration']);
      $log['request_time'] = $now->toSql();
      $log['request_date'] = $now->format('Y-m-d');
      $log['endpoint'] = $endpoint;
      switch ($access_type) {
        case 'user':
          $log['access_type'] = 1;
          break;
        case 'key':
          $log['access_type'] = 2;
          break;
        case 'free':
        default:
          $log['access_type'] = 0;
          break;
      }
    }

    $this->item = $this->get('Item');

    // Check for errors
    if (count($errors = $this->get('Errors'))) {
      JError::raiseError(500, implode("\n", $errors));
      return false;
    }

    if ($enable_trace)
    {
      // Collect post-execution log information
      $log['error'] = (int)($this->item['status'] == 'ko');
      $log['error_code'] = ($log['error']) ? $this->item['error_code'] : '';
      $log['user_id'] = JFactory::getUser()->id;
      $log['key'] = $app->input->getString('api_key', '');
      $log['module'] = $app->input->getString('module', '');
      $log['action'] = $app->input->getString('action', '');
      $log['resource'] = $app->input->getString('resource', '');
      $log['duration'] = microtime(true) - $log['duration'];

      // Save log information
      jBackendHelper::logRequest($log);
     }

    // Use the correct json mime-type
    header('Content-Type: application/json');

    // Change the suggested filename
    header('Content-Disposition: attachment;filename="response.json"');

    // Enable CORS
    if ($enable_cors != '0')
    {
      header('Access-Control-Allow-Origin: *');
      header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');
      header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    }

    // Output the JSON data
    $response = $this->item;
    echo json_encode($response);

    JFactory::getApplication()->close();
  }

}
