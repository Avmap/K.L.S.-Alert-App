<?php
/**
 * jBackend component for Joomla
 *
 * @author selfget.com (info@selfget.com)
 * @package jBackend
 * @copyright Copyright 2014 - 2018
 * @license GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @link http://www.selfget.com
 * @version 3.8.0
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class jBackendModelRequest extends JModelItem
{
  /**
   * Method to get response data
   *
   * @return  array  An array with the response data or the error data
   */
  public function getItem()
  {
    $app = JFactory::getApplication('site');
    $dispatcher = JEventDispatcher::getInstance();

    JPluginHelper::importPlugin('jbackend');

    // Before check module
    $dispatcher->trigger('onBeforeCheckModule');

    $module = $app->input->getString('module');
    if (is_null($module))
    {
      return jBackendHelper::generateError('REQ_MNS'); // Module not specified
    }

    // Check request session
    $session_data = null;
    $dispatcher->trigger('onCheckSession', array($module, &$session_data));

    // Get base path and API key
    $access_type = jBackendHelper::globals_get('session', 'access_type');
    $enabled_modules = jBackendHelper::globals_get('session', 'enabled_modules');
    $selected_modules = jBackendHelper::globals_get('session', 'selected_modules');

    if (($enabled_modules !== '1') && (!in_array($module, $selected_modules)))
    {
      return jBackendHelper::generateError('REQ_MNF'); // Module not found
    }

    if ($access_type === 'key')
    {
      // Check API key
      $api_key = null;
      if (isset($_SERVER['HTTP_AUTHORIZATION']))
      {
        $header_auth = explode(' ', $_SERVER['HTTP_AUTHORIZATION']);
        if ($header_auth[0] === 'api_key') $api_key = $header_auth[1];
      }
      if (is_null($api_key))
      {
        // Get the input data as JSON
        $json = new JInputJSON;
        $json_data = json_decode($json->getRaw(), true);

        $api_key = (isset($json_data)) ? @$json_data['api_key'] : $app->input->getString('api_key');
      }
      if (is_null($api_key))
      {
        return jBackendHelper::generateError('REQ_AKR'); // API key required
      }
      $key_status = $this->checkAPIKey($api_key); // 0 = Valid, 1 = Limit exceeded, 2 = Expired, 3 = Invalid, 4 = Generic error
      if ($key_status > 0)
      {
        switch ($key_status)
        {
          case 1: return jBackendHelper::generateError('REQ_AKL'); // API key limit exceeded
          case 2: return jBackendHelper::generateError('REQ_AKE'); // API key expired
          case 3: return jBackendHelper::generateError('REQ_AKI'); // API key invalid
          default: return jBackendHelper::generateError('REQ_AKG'); // API key generic error
        }
      }
    } else if ($access_type === 'user') {
      // Check user authentication
      if (is_null($session_data))
      {
        return jBackendHelper::generateError('REQ_UCA'); // Unable to check authentication
      }
      if ( ($session_data['is_guest']) && !($session_data['is_auth_request']) )
      {
        return jBackendHelper::generateError('REQ_AUR'); // Authentication required
      }
    }

    $response = null;
    $status = null;
    $dispatcher->trigger('onRequest'.$module, array($module, &$response, &$status));
    if (is_null($response))
    {
      if (isset($status->module_stack))
      {
        return jBackendHelper::generateError('REQ_RUN'); // Request unknown
      } else {
        return jBackendHelper::generateError('REQ_MNF'); // Module not found
      }
    }

    return $response;
  }

  public function checkAPIKey($key)
  {
    // 0 = Valid, 1 = Limit exceeded, 2 = Expired, 3 = Invalid, 4 = Generic error
    $check_result = 4; // Generic error

    $db = $this->getDbo();
    $db->setQuery("SELECT * FROM `#__jbackend_keys` WHERE `published` = '1' AND `key` = " . $db->quote($key));
    $keys = $db->loadAssocList();
    if (is_array($keys))
    {
      if (isset($keys[0]))
      {
        $is_default = jBackendHelper::globals_get('session', 'is_default');
        $endpoint = jBackendHelper::globals_get('session', 'endpoint');
        $selected_endpoints= explode(',', $keys[0]['selected_endpoints']);

        if (((!$is_default) && (($keys[0]['enabled_endpoints']) || (in_array($endpoint, $selected_endpoints)))) || ($is_default && $keys[0]['enabled_on_default']))
        {
          $now = JFactory::getDate();
          // Check expired
          $expiration_date = JFactory::getDate($keys[0]['expiration_date'], 'UTC');
          if ( ($keys[0]['expiration_date'] != '0000-00-00 00:00:00') && ($expiration_date->toUnix() <= $now->toUnix()) )
          {
            $check_result = 2; // Expired
          } else {
            // Check limit exceeded
            $today = $now->format('Y-m-d');
            $current_day = JFactory::getDate($keys[0]['current_day'], 'UTC')->format('Y-m-d');
            $current_hits = $keys[0]['current_hits']++;

            if (($keys[0]['current_day'] == '0000-00-00 00:00:00') || ($current_day != $today))
            {
              // Not valid date (i.e. 0000-00-00 00:00:00) || Restart on different day
              $current_day = $today;
              $current_hits = 0;
            }

            if ($keys[0]['daily_requests'] > 0)
            {
              // Check hits
              $check_result = ($current_hits >= $keys[0]['daily_requests']) ? 1 : 0; // 1 = Limit exceeded, 0 = Valid
            } else {
              // Unlimited
              $check_result = 0; // Valid
            }

            if ($check_result == 0)
            {
              // Update key stats
              $last_visit = $now->toSql();
              $current_hits++;
              $db->setQuery("UPDATE `#__jbackend_keys` SET `hits` = `hits` + 1, `last_visit` = " . $db->quote($last_visit) . ", `current_day` = " . $db->quote($current_day) . ", `current_hits` = " . $db->quote($current_hits) . " WHERE `key` = " . $db->quote($key));
              $res = @$db->query();
            }

          }

        } else {
          $check_result =3; // Invalid
        }

      } else {
        $check_result =3; // Invalid
      }
    }
    return $check_result;
  }

}
